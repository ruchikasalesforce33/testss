const quizData = [
  {
    question: "What is the capital of France?",
    options: ["Paris", "Madrid", "Berlin", "Rome"],
    answer: "Paris"
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Earth", "Mars", "Saturn", "Venus"],
    answer: "Mars"
  },
  {
    question: "What is the largest mammal?",
    options: ["Elephant", "Giraffe", "Blue Whale", "Rhino"],
    answer: "Blue Whale"
  },
  {
    question: "Which language is used for web apps?",
    options: ["Python", "Java", "C++", "JavaScript"],
    answer: "JavaScript"
  },
  {
    question: "Who wrote 'Romeo and Juliet'?",
    options: ["Charles Dickens", "William Shakespeare", "Mark Twain", "Leo Tolstoy"],
    answer: "William Shakespeare"
  }
];

const quizForm = document.getElementById('quiz-form');

quizData.forEach((q, index) => {
  const questionDiv = document.createElement('div');
  questionDiv.classList.add('question');
  questionDiv.innerHTML = `
    <h3>${index + 1}. ${q.question}</h3>
    ${q.options.map(opt => `
      <label class="option">
        <input type="radio" name="q${index}" value="${opt}"> ${opt}
      </label>
    `).join('')}
  `;
  quizForm.appendChild(questionDiv);
});

document.getElementById('submit-btn').addEventListener('click', () => {
  let score = 0;
  const resultDiv = document.getElementById('result');
  resultDiv.innerHTML = "";

  quizData.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    const isCorrect = selected && selected.value === q.answer;

    if (isCorrect) score++;

    const feedback = document.createElement('p');
    feedback.innerHTML = `
      ${index + 1}. ${q.question} - 
      <span class="${isCorrect ? 'correct' : 'incorrect'}">
        ${isCorrect ? 'Correct ✅' : `Incorrect ❌ (Answer: ${q.answer})`}
      </span>
    `;
    resultDiv.appendChild(feedback);
  });

  const scoreMessage = document.createElement('h2');
  scoreMessage.textContent = `🏁 You scored ${score} out of ${quizData.length}`;
  resultDiv.prepend(scoreMessage);
});
