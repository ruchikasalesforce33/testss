// Highlight active navbar link
document.addEventListener('DOMContentLoaded', () => {
  const navbarLinks = document.querySelectorAll('.navbar a');
  const currentPath = window.location.pathname.split('/').pop(); // get current filename

  navbarLinks.forEach(link => {
    const linkPath = link.getAttribute('href');
    if (linkPath === currentPath) {
      link.classList.add('active');
    }
  });
});

// SIGNUP logic
document.getElementById('signup-form')?.addEventListener('submit', function (e) {
  e.preventDefault();

  const username = document.getElementById('username').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const messageDiv = document.getElementById('form-message');

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!username || !email || !password) {
    messageDiv.textContent = "All fields are required.";
    messageDiv.style.color = "red";
    return;
  }

  if (!emailRegex.test(email)) {
    messageDiv.textContent = "Invalid email format.";
    messageDiv.style.color = "red";
    return;
  }

  if (password.length < 6) {
    messageDiv.textContent = "Password must be at least 6 characters.";
    messageDiv.style.color = "red";
    return;
  }

  const hashedPassword = btoa(password); // simple encoding

  const users = JSON.parse(localStorage.getItem('users') || '[]');

  const emailExists = users.find(user => user.email === email);
  if (emailExists) {
    messageDiv.textContent = "User with this email already exists.";
    messageDiv.style.color = "red";
    return;
  }

  users.push({ username, email, password: hashedPassword });
  localStorage.setItem('users', JSON.stringify(users));

  messageDiv.textContent = "✅ Signup successful!";
  messageDiv.style.color = "lightgreen";
  this.reset();
});

// LOGIN logic
document.getElementById('login-form')?.addEventListener('submit', function (e) {
  e.preventDefault();

  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const messageDiv = document.getElementById('login-message');

  const hashedPassword = btoa(password); // encoding same as signup
  const users = JSON.parse(localStorage.getItem('users') || '[]');

  const match = users.find(user => user.email === email && user.password === hashedPassword);

  if (match) {
    messageDiv.textContent = "✅ Login successful!";
    messageDiv.style.color = "lightgreen";
    // Redirect to dashboard after login success (optional)
    // setTimeout(() => {
    //   window.location.href = 'dashboard.html';
    // }, 1000);
  } else {
    messageDiv.textContent = "❌ Invalid credentials.";
    messageDiv.style.color = "red";
  }
});
