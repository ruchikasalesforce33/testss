<form id="signupForm">
  <div class="mb-3">
    <input type="text" id="name" class="form-control" placeholder="Full Name" required>
  </div>
  <div class="mb-3">
    <input type="email" id="email" class="form-control" placeholder="Email" required>
  </div>
  <div class="mb-3">
    <input type="password" id="password" class="form-control" placeholder="Password" required>
  </div>
  <button type="submit" class="btn btn-dark w-100">Sign Up</button>
</form>

<script>
  document.getElementById("signupForm").addEventListener("submit", function(e) {
    e.preventDefault();
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    let users = JSON.parse(localStorage.getItem("users")) || [];
    users.push({ name, email, password });
    localStorage.setItem("users", JSON.stringify(users));

    alert("Account created successfully!");
    window.location.href = "index.html"; // Redirect to login
  });
</script>
