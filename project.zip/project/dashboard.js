const userTableBody = document.querySelector("#userTable tbody");

// Load users
let users = JSON.parse(localStorage.getItem("users")) || [];
renderTable();

// Render dashboard table
function renderTable() {
  userTableBody.innerHTML = "";
  users.forEach((u, i) => {
    let row = `<tr>
      <td>${u.username}</td>
      <td>${u.email}</td>
      <td>${u.password.substring(0, 15)}...</td>
      <td><button class="btn btn-danger btn-sm" onclick="deleteUser(${i})">Delete</button></td>
    </tr>`;
    userTableBody.innerHTML += row;
  });
}

// Delete user
function deleteUser(index) {
  if (confirm("Delete this user?")) {
    users.splice(index, 1);
    localStorage.setItem("users", JSON.stringify(users));
    renderTable();
  }
}
